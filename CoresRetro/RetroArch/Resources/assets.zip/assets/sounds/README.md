# Sounds
Sounds were compiled from the /sounds/ and /src/sounds/ directories of the **retroarch-assets** repository.  Themes can be configured to use sounds using the configuration files in their respective icon directory.
